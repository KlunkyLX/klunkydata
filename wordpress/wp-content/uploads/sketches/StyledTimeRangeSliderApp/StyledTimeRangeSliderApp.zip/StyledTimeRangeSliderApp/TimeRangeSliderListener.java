
import org.joda.time.DateTime;

public interface TimeRangeSliderListener {

	public void timeUpdated(DateTime startDateTime, DateTime endDateTime);

}
